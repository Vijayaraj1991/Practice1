package firstProgram;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.batik.apps.rasterizer.Main;
import org.apache.poi.ss.usermodel.Workbook;

public class ReadandWriteExcelSheet {

	public void readExcel(String fileName, String EmpID, String Phonenumber, String Address) throws FileNotFoundException {

		String excel = null;

		//create an object of file class to open XLSS file

		FileInputStream inputstream = new FileInputStream(excel);

		Workbook Book1 = null;

		String fileExtensionName = fileName.substring(fileName.indexOf("."));


		// Check the conditon if the file is Xlss

		if(fileExtensionName.equals(".xls")) {

			//If it is xls file then create object of HSSFWorkbook class


		}

	}

	public static void main(String[] args) throws FileNotFoundException {
		
		ReadandWriteExcelSheet readpage = new ReadandWriteExcelSheet();
		readpage.readExcel("Vijay", "6354", "super", "velore");
		System.out.println(readpage);



	}



}
