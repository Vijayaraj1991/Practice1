package firstProgram;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.batik.apps.rasterizer.Main;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class ReadtheExcelData {

	static List<String> usernamelist = new ArrayList<String>();
	static List<String> Passwordlist = new ArrayList<String>();
	WebDriver driver;
	
	@BeforeTest
	public void login() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");
		
		 driver = new ChromeDriver();
		 
		 driver.get("http://www.leafground.com/");
		 
		 driver.manage().window().maximize();
		 
		 driver.quit();
		
	}


	public void readExcel1() throws IOException {

		FileInputStream excel = new FileInputStream("C:\\Users\\vijayarajkr\\Desktop\\TestData.xlsx");

		Workbook workbook = new XSSFWorkbook(excel);

		Sheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowiterator =	sheet.iterator();

		while(rowiterator.hasNext()) {

			Row rowvalue =	rowiterator.next();

			Iterator<Cell> columnIterator =	rowvalue.iterator();
			int i = 2;
			while(columnIterator.hasNext()) {

				if(i%2==0) {
					usernamelist.add(columnIterator.next().toString().trim());

				}else {
					Passwordlist.add(columnIterator.next().toString().trim());
				}

				i++;

			}
			
			
		}
		
		

	}

	public static void main(String[] args) throws IOException {

		ReadtheExcelData data = new ReadtheExcelData();
		data.readExcel1();
		System.out.println("user name list: "+usernamelist);
		System.out.println("password list is : "+Passwordlist);
		data.login();

	}

}
