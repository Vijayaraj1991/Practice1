package firstProgram;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Programstarted {

	static WebDriver driver;
	
	String Sheet = null;

	public static void main(String[] args) throws FileNotFoundException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("http://www.leafground.com/");
		
		Programstarted started = new Programstarted();
		started.readExcel();
		
	}

	public void readExcel() throws FileNotFoundException {

		FileInputStream excel = new FileInputStream("C:\\Users\\vijayarajkr\\Desktop//TestData.xlsx");

		Workbook workbook = new XSSFWorkbook();

		Sheet sheet = workbook.getSheet("Sheet1");

		Iterator<Row> rowiterator = sheet.iterator();

		while(rowiterator.hasNext()) {

			Row rowvalue =	rowiterator.next();
           int i = 2;
			Iterator<Cell> celliterator = rowvalue.iterator();
			
			if(i%2==0) {
				Cell cellterator =celliterator.next();
				
					}else {
						
						Cell cellterator =	celliterator.next();
					}

			while(celliterator.hasNext()) {
				Cell cellterator =		 celliterator.next();
				
				System.out.println(celliterator);

			}
			
			i++;

		}
	}

}
