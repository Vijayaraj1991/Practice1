package firstProgram;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FlipKartLogin {
	
	WebDriver driver;
	@Test
	public void loginFilpKart() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Thread.sleep(30);
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")).sendKeys("revanth.bunny2008@gmail.com");
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys("flip@1234");
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button/span")).submit();
		
		}

}
