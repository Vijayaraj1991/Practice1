package com.PageObjectModls;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PageObjectsLoginTestcase {
	
	public static WebElement userName(WebDriver driver) {
		
		 driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		return null;
				
		
	}
	
	public static WebElement pwd(WebDriver driver) {
		
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		return null;
		
	}
	
	public static WebElement submitButton(WebDriver driver) {
		
		driver.findElement(By.id("btnLogin")).click();
		return null;
		
		
	}

}
