package com.dataDriverframwork;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DataDriverUsingPOI {
	
	
	
	static List<String> uname = new ArrayList<String>();
	static List<String> pwd = new ArrayList<String>();
	
	public void login(String username1, String pwd1) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/");
		 
		 driver.manage().window().maximize();
		 
		 WebElement username =	driver.findElement(By.id("txtUsername"));
			
			username.sendKeys("username1");
			
			WebElement pwd = driver.findElement(By.id("txtPassword"));
			pwd.sendKeys("pwd1");
			
			WebElement loginbtn = driver.findElement(By.id("btnLogin"));
			loginbtn.click();
			driver.quit();
	}
	
	public void execte() {
		
		for(int i=0;i<uname.size();i++) {
			login(uname.get(i),pwd.get(i));
			
		}
    	
    	
    }
	
	
	
	public void excelUsingPoI() throws IOException {
		
		FileInputStream excel = new FileInputStream("C:\\Users\\vijayarajkr\\Desktop\\TestData.xlsx");
		
	    Workbook workbook = new XSSFWorkbook(excel);
	    
	    Sheet sheet = workbook.getSheetAt(0);
	    
	    Iterator<Row> rowIterator = sheet.iterator();
	    
	    while(rowIterator.hasNext()) {
	 
	    	Row rowValue =  	rowIterator.next();
	    	
	    	Iterator<Cell> columnIterator =	rowValue.iterator();
	    	int i =2;
	    	while (columnIterator.hasNext()) {
	    		
	    		if(i%2==0) {
	    			uname.add(columnIterator.next().toString());
	    		}
	    		
	    		else {
	    			pwd.add(columnIterator.next().toString());
	    		}
	    		
	    		i++;
	    	}
	    	
	    	
	    	
	    	
	    }
	    

	    
	    
	}
	
	public static void main(String[] args) throws IOException {
		
		DataDriverUsingPOI excel1 = new DataDriverUsingPOI();
		excel1.excelUsingPoI();
		System.out.println("user name list is :"+uname);
		System.out.println("pwd is :"+pwd);
		excel1.execte();
		
		}

}
