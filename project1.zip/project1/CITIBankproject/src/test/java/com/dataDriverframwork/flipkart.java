package com.dataDriverframwork;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class flipkart {

	WebDriver driver;
	@Test(priority=0)
	public void launchBrowser() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("https://www.flipkart.com/");

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	    Thread.sleep(3000);

		//locating elements with attribute

		driver.findElement(By.xpath("//*[@class='_2IX_2- VJZDxU']")).sendKeys("revanth.bunny2008@gmail.com");

		//locating elements with known Element name and known attribute

		driver.findElement(By.xpath("//input[@class='_2IX_2- _3mctLh VJZDxU']")).sendKeys("flip@1234");

		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button/span")).submit();

		driver.manage().window().maximize();

		Thread.sleep(5000);

		driver.findElement(By.xpath("//*[@class='xtXmba' and text()= 'Mobiles']/parent::*")).click();

	}
	@Test(priority=1)
	public void selectCategoryMen() throws InterruptedException {

		driver.findElement(By.xpath("//*[@class='_2I9KP_' and text()= 'Men']")).click();

		//selected jeans category

		driver.findElement(By.xpath("//*[@title='Jeans']")).click();

		//select the check box Assured 

		driver.findElement(By.xpath("//*[@class='_24_Dny _3tCU7L']")).click();

		//To customer ratings 4 & above


		Thread.sleep(5000);

		WebElement ratingcheckbox =	driver.findElement(By.xpath("//*[@class='_3879cV' and text()='4★ & above']"));

		ratingcheckbox.click();

		Thread.sleep(5000);

		WebElement checkbox =   driver.findElement(By.xpath("//*[@class='_3879cV' and text()='No Cost EMI']"));

		checkbox.click();

	}
    @Test(priority=2)
	public void discountAndOtherDetails() throws InterruptedException {
    	
    

    	Thread.sleep(5000);
    	
		driver.findElement(By.xpath("//*[@class='_2gmUFU _3V8rao' and text()='Discount']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@class='_3879cV' and text()='30% or more']")).click();
		
		Thread.sleep(5000);

		driver.findElement(By.xpath("//*[@class='_3sckoD' and text()='30% or more']")).click();
		
		Thread.sleep(5000);
		
		WebElement pantsize = driver.findElement(By.xpath("//*[@class='ge-49M _2Kfbh8']"));
		
		pantsize.click();
		
		pantsize.getSize();
		
		System.out.println("pant size is :"+pantsize);
		
		//Ideal for Men alone 
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@class='_2gmUFU _3V8rao' and text()='Ideal For']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@class='_3879cV' and text()='Men']")).click();
		
		//click price low to high
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@class='_10UF8M' and text()='Price -- Low to High']")).click();

}
} 	 	


