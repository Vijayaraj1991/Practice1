package com.dataDriverframwork;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

public class ListOfElements {
	
	@Test
	public void ListOfArrays() {
		
		List<String> arraylist = new ArrayList<String>();
		
		arraylist.add("Vijay");
		arraylist.add("kumar");
		arraylist.add("ram");
		arraylist.add("praba");
		arraylist.add("barath");
		arraylist.add("mani");
		
		//How many arays present in the below list:
		
	//	System.out.println(arraylist);
		
		//check and verify the below index position 
		
	//	System.out.println(arraylist.get(0));
	//	System.out.println(arraylist.get(3));
		
		// Total size of the below position
		
		System.out.println(arraylist.size());
		
		System.out.println(arraylist.indexOf("barath"));
		
		System.out.println(arraylist.lastIndexOf(arraylist));
		
		List<String> anotherlist = new ArrayList<String>();
		
		System.out.println(anotherlist.addAll(arraylist));
		
		System.out.println(anotherlist);
		
		System.out.println(arraylist);
		
		System.out.println(anotherlist.isEmpty());
		
		arraylist.remove(1);
		
		System.out.println(arraylist);
		
		arraylist.add(null);
		System.out.println(arraylist);
		
		anotherlist.clear();
		System.out.println(anotherlist);
		
		System.out.println("-----------------------------------");
		
		for(int i=0;i<arraylist.size();i++) {
			System.out.println(arraylist.get(i));
		}
		
			
			
		}
		
	}


