package com.dataDriverframwork;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DataDrivenFrameworkUsingPOI {

	static List<String> userName = new ArrayList<>();
	static List<String> password = new ArrayList<>();
	
	public void login(String uName, String pwd) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CITIBankproject\\src\\Driverpath\\ChromeDriver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/");
		 
		 driver.manage().window().maximize();
		 
		 WebElement username =	driver.findElement(By.id("txtUsername"));
			
			username.sendKeys("uName");
			
			WebElement pwd1 = driver.findElement(By.id("txtPassword"));
			pwd1.sendKeys("password");
			
			WebElement loginbtn = driver.findElement(By.id("btnLogin"));
			loginbtn.click();
			driver.quit();
	}
	
	public void executetest() {
		for(int i=0;i<userName.size();i++) {
			login(userName.get(i),password.get(i));
			
		}
		
	}


	public void excelUsingPOI() throws IOException {

		//Create an Object for FileInputStream
		//Create Workbook 
		//Create Sheet
		//Create row
		//Create Column

		FileInputStream excel = new FileInputStream("C:\\Users\\vijayarajkr\\Desktop\\TestData.xlsx");

		Workbook workbook = new XSSFWorkbook(excel);

		Sheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowIterator = sheet.iterator();

		while(rowIterator.hasNext()) {
			Row rowvalue = rowIterator.next();

			Iterator<Cell>  columnIterator = rowvalue.iterator();

			int i = 2;

			while(columnIterator.hasNext()) {
				if (i%2==0) {

					userName.add (columnIterator.next().toString());

				}else {
					password.add(columnIterator.next().toString());
					
					
}
				
				
				i++;
			}
		}
		
		
	}
	public static void main(String[] args) throws IOException {

		DataDrivenFrameworkUsingPOI excelData = new DataDrivenFrameworkUsingPOI();

		excelData.excelUsingPOI();
		
		System.out.println("user name list is :"+userName);
		System.out.println("pwd is : "+password);
		
		excelData.executetest();
		
		}

}

