package com.CollectionFramework;

import java.util.HashMap;

import org.apache.poi.common.Duplicatable;

public class HashMapone {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> mapone = new HashMap<Integer, String>();
		
		mapone.put(1, "Aditiya");
		mapone.put(2, "Ram");
		mapone.put(4, "kumar");
		mapone.put(3, "prabha");
		mapone.put(6, "Barath");
		mapone.put(5, "vijay");
		mapone.put(null, null);
		
		//To print the values to store the HashMap values - Key and value pair 
		
        //Key is a unique value, where as the value is not a unique one
		
		System.out.println("mappne list displayed as the order:"+mapone);
		
		//To merge duplicate key and value pair
		
		HashMap<Integer,String> dulicatevalue = new HashMap<Integer,String>();
		
		dulicatevalue.putAll(mapone);
		
		System.out.println("Its should displayed the duplicate values:"+dulicatevalue);
		
		HashMap<String,String> superone = new HashMap<String,String>();
		superone.put("Aru", "Mani");
		superone.put("sakthi", "selvi");
		superone.put("vijay", "subha");
		superone.put("prabha", "swathi");
		System.out.println("superone:"+superone);
		
		//To find whether the key is present or not 
		
		System.out.println("mapone is :"+mapone.containsKey(5));
		
		System.out.println("mapone value :"+mapone.containsValue("Ram"));
		
		System.out.println(mapone.isEmpty());
		
		System.out.println(mapone.clone());
		
		dulicatevalue.clear();
		System.out.println("duplicate value is displayed :"+dulicatevalue);
		
		mapone.get(1);
		
		System.out.println(mapone);
	}

}
