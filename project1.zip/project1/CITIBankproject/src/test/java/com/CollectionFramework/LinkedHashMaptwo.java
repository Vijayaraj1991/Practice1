package com.CollectionFramework;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashMaptwo {
	
	public static void main(String[] args) {
		
		LinkedHashMap<String,String> linkedhashmap = new LinkedHashMap<String,String>();
		
		linkedhashmap.put("krish", "Rajam");
		linkedhashmap.put("Arul", "ratha");
		linkedhashmap.put("azagesan", "jayanthi");
		
		System.out.println(linkedhashmap);
		
		
		LinkedHashMap<Integer,String> linkedhashmapnumber = new LinkedHashMap<Integer,String>();
		
		linkedhashmapnumber.put(1, "Moorthy");
		linkedhashmapnumber.put(3, "junguly");
		linkedhashmapnumber.put(2, "boongle");
		System.out.println(linkedhashmapnumber);
		
		HashMap<String, String> hashmap = new HashMap<String,String>();
		hashmap.put("Ravi", "Valli");
		hashmap.put("mani", "kani");
		hashmap.put("teja", "sri");
		System.out.println(hashmap);
		
		System.out.println(linkedhashmapnumber.containsKey(4));
		System.out.println(linkedhashmapnumber.containsValue("kavi"));
		System.out.println(linkedhashmapnumber.containsValue("Moorthy"));
		
		
		
	}

}
