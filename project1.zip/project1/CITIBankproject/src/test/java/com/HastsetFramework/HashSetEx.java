package com.HastsetFramework;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class HashSetEx {

	public static void main(String[] args) {

		HashSet<String> hashset = new HashSet<String>();

		hashset.add("A");
		hashset.add("b");
		hashset.add("c");
		hashset.add("d");
		hashset.add("e");
		hashset.add("f");
		hashset.add("g");
		hashset.add("A");
		hashset.add("a");

		System.out.println(hashset);

		System.out.println(hashset.contains("c"));

		System.out.println(hashset.isEmpty());

		System.out.println(hashset.clone());

		System.out.println(hashset.size());

		System.out.println(hashset.equals("e"));

		Iterator<String> ls = hashset.iterator();

		while(ls.hasNext()) {

			System.out.println(ls.next());


		}

		System.out.println("==========================================");

		ArrayList<Integer> arraylist = new ArrayList<Integer>();

		arraylist.add(100);
		arraylist.add(110);
		arraylist.add(120);
		arraylist.add(130);
		arraylist.add(140);

		System.out.println(arraylist);

		Iterator<Integer> valuepart =	arraylist.iterator();

		while(valuepart.hasNext()) {

			Integer i =	valuepart.next();
			if(i<110) {
				valuepart.remove();
			}
}


		System.out.println(arraylist);
		
		LinkedHashSet linkedhashset = new LinkedHashSet();
		
		linkedhashset.add("kumar");
		linkedhashset.add("vinay");
		linkedhashset.add("dhinei");
		linkedhashset.add("suoer");
		
	Iterator lm =	linkedhashset.iterator();
	
	while(lm.hasNext()) {
		
		lm.next();
		
		
	}
		
	System.out.println(linkedhashset);
	
	linkedhashset.remove("kumar");
		
	System.out.println(linkedhashset.contains("vinay"));
	
	System.out.println(linkedhashset.equals("suoer"));
	
	

}

}
