package com.String;

import org.testng.annotations.Test;

public class CreateStringObjects {
	@Test
	public void stringWorkouts() {
		
		String string1 = "Vijay";
		
		//check to find out the charat
		
		System.out.println(string1.charAt(2));
		
		//check the lenght of the string 
		
		System.out.println(string1.length());
		
		//check the equals of the created string 
		
		System.out.println(string1.equals("Vijay"));
		
		//check the equals of the created string 
		
		System.out.println(string1.equals("vijay"));
		
		//Check the equals ignorance case 
		
		System.out.println(string1.equalsIgnoreCase("vijay"));
		
		//To check whether the created object is same or not
		
		System.out.println(string1.equals("Ram"));
		
		//To check whether the object is empty
		
		System.out.println(string1.isEmpty());
		
		//To check whether the object is blank
		
		System.out.println(string1.isBlank());
		
		//To check whether the object contains a
		
		System.out.println(string1.contains("a"));
		
		// To check whether the object contains m
		
		System.out.println(string1.contains("m"));
		
		//To check whether the object is sub string
		
		System.out.println(string1.substring(3));
		
		System.out.println(string1.substring(1,3));
		
		//To chceck whether the object is concat
		
		System.out.println(string1.concat("super"));
		
		//To replace the object craeted 
		
		System.out.println(string1.replace("a", "m"));
		
		//index position 
		
		System.out.println(string1.indent(2));
		
		//trim 
		
		System.out.println(string1.trim());
		
		
	}

}
