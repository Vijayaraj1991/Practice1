package ExceptionHandling;

public class Examplenumber1 {
	
	static int a =10;
	static int b =20;
	 static int result = a-b;
	
	 static String name = "Vijay";
	
	public static void main(String[] args) {
		
		Examplenumber1 numbers = new Examplenumber1();
		
		numbers.carSale();
		
		
		try {
			
		  	System.out.println(name);
		}
		
		catch(ArithmeticException e) {
			
			System.out.println(result);
		}
		
		catch(NullPointerException e) {
			
			System.out.println();
			
			
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
			System.out.println(name);
		}
		
		
		
	}
	
	public void carSale() {
		
	 String mergo;
	
	
	
	
	}

}
